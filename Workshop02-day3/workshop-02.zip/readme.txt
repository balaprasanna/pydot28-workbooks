================
|For workshop 2|
================

1. Attempt this workshop, at end of the FILE I/O module(Day 3)